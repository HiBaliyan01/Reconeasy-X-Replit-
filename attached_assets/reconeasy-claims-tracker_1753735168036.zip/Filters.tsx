import React from 'react';

const Filters = () => (
  <div className="flex gap-4 mb-4">
    <select className="border p-2">
      <option>All Marketplaces</option>
      <option>Amazon</option>
      <option>Flipkart</option>
    </select>
    <select className="border p-2">
      <option>All Statuses</option>
      <option>Open</option>
      <option>In Progress</option>
      <option>Resolved</option>
    </select>
    <input className="border p-2 flex-1" placeholder="Search by Order ID or Issue" />
  </div>
);

export default Filters;