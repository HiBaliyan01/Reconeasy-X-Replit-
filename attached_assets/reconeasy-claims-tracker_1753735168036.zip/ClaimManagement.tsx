import React, { useState, useEffect } from 'react';
import ClaimDetailView from './ClaimDetailView';
import Filters from './Filters';
import ClaimStatusBadge from './ClaimStatusBadge';

const mockClaims = [
  {
    id: 'ORD123',
    marketplace: 'Amazon',
    issueType: 'Payment Discrepancy',
    status: 'Pending',
    daysOpen: 11,
    claimValue: 2400,
  },
  {
    id: 'ORD456',
    marketplace: 'Flipkart',
    issueType: 'Return Rejected',
    status: 'Open',
    daysOpen: 16,
    claimValue: 1200,
  },
];

const ClaimManagement = () => {
  const [claims, setClaims] = useState(mockClaims);
  const [selectedClaims, setSelectedClaims] = useState<string[]>([]);
  const [bulkStatus, setBulkStatus] = useState('');
  const [selectedClaimId, setSelectedClaimId] = useState<string | null>(null);

  const handleBulkUpdate = () => {
    setClaims(prev =>
      prev.map(claim =>
        selectedClaims.includes(claim.id)
          ? { ...claim, status: bulkStatus }
          : claim
      )
    );
    setSelectedClaims([]);
  };

  if (selectedClaimId) {
    return <ClaimDetailView claimId={selectedClaimId} onBack={() => setSelectedClaimId(null)} />;
  }

  return (
    <div className="p-4">
      <Filters />
      <div className="overflow-x-auto mt-4">
        <table className="table-auto w-full border rounded">
          <thead>
            <tr>
              <th><input type="checkbox" onChange={e => {
                setSelectedClaims(e.target.checked ? claims.map(c => c.id) : []);
              }} /></th>
              <th>Order ID</th>
              <th>Marketplace</th>
              <th>Issue</th>
              <th>Status</th>
              <th>Claim Value</th>
              <th>Days Open</th>
            </tr>
          </thead>
          <tbody>
            {claims.map(claim => (
              <tr key={claim.id}>
                <td><input type="checkbox" checked={selectedClaims.includes(claim.id)} onChange={() => {
                  setSelectedClaims(prev => prev.includes(claim.id)
                    ? prev.filter(id => id !== claim.id)
                    : [...prev, claim.id]);
                }} /></td>
                <td>
                  <button className="text-blue-600 underline" onClick={() => setSelectedClaimId(claim.id)}>{claim.id}</button>
                </td>
                <td>{claim.marketplace}</td>
                <td>{claim.issueType}</td>
                <td><ClaimStatusBadge status={claim.status} daysOpen={claim.daysOpen} /></td>
                <td>₹{claim.claimValue}</td>
                <td>{claim.daysOpen} days</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selectedClaims.length > 0 && (
        <div className="mt-4 p-2 border rounded bg-gray-100">
          <label>Status to update: </label>
          <select value={bulkStatus} onChange={e => setBulkStatus(e.target.value)}>
            <option value="">Select Status</option>
            <option value="Open">Open</option>
            <option value="In Progress">In Progress</option>
            <option value="Resolved">Resolved</option>
            <option value="Escalated">Escalated</option>
          </select>
          <button onClick={handleBulkUpdate} className="ml-2 bg-[var(--primary)] text-white px-3 py-1 rounded">Update</button>
        </div>
      )}
    </div>
  );
};

export default ClaimManagement;