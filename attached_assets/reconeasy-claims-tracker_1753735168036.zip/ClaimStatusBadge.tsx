import React from 'react';

const ClaimStatusBadge = ({ status, daysOpen }) => {
  let color = 'gray';
  if (status === 'Resolved') color = 'green';
  else if (daysOpen > 15) color = 'red';
  else if (daysOpen > 7) color = 'orange';

  return <span className={`text-xs px-2 py-1 rounded bg-${color}-100 text-${color}-800`}>{status}</span>;
};

export default ClaimStatusBadge;