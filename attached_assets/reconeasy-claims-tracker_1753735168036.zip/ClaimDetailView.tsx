import React from 'react';

const ClaimDetailView = ({ claimId, onBack }) => {
  return (
    <div className="p-4">
      <button className="mb-4 text-sm text-blue-500 underline" onClick={onBack}>← Back to Claims</button>
      <h2 className="text-xl font-bold mb-2">Claim Details for {claimId}</h2>
      <p>Expected Refund: ₹2400</p>
      <p>Actual Refund: ₹0</p>
      <p>Suggested Reason: Short Refund</p>
      <p>Marketplace Ticket ID: N/A</p>
      <textarea placeholder="Add a comment..." className="w-full p-2 border mt-2"></textarea>
      <div className="mt-2">
        <select>
          <option>Open</option>
          <option>In Progress</option>
          <option>Resolved</option>
        </select>
        <button className="ml-2 bg-[var(--primary)] text-white px-3 py-1 rounded">Update</button>
        <button className="ml-2 border px-3 py-1 rounded">Download PDF</button>
      </div>
    </div>
  );
};

export default ClaimDetailView;