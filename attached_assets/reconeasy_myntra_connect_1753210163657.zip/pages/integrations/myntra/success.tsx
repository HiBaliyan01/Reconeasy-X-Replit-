import { useEffect } from "react";
import { useRouter } from "next/router";
import axios from "axios";

export default function MyntraSuccess() {
  const router = useRouter();

  useEffect(() => {
    const handleSuccess = async () => {
      const { token } = router.query;

      if (token) {
        try {
          await axios.post("/api/integrations/myntra/store", { token });
          alert("✅ Myntra connected successfully!");
        } catch (err) {
          alert("❌ Failed to connect. Please try again.");
        }
      }

      setTimeout(() => {
        router.push("/settings/integrations");
      }, 5000);
    };

    if (router.isReady) {
      handleSuccess();
    }
  }, [router]);

  return (
    <div className="text-center p-4">
      ✅ Myntra connected successfully.<br />Redirecting to dashboard...
    </div>
  );
}