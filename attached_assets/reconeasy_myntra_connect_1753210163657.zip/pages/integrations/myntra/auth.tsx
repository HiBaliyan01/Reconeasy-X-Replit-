import { useEffect } from "react";
import { useRouter } from "next/router";

export default function MyntraAuth() {
  const router = useRouter();

  useEffect(() => {
    const successUrl = encodeURIComponent("https://reconeasy.replit.app/integrations/myntra/success");
    const myntraLoginUrl = `https://partners.myntra.com/login?redirect_uri=${successUrl}`;

    window.location.href = myntraLoginUrl;
  }, []);

  return <div className="p-4 text-center">🔄 Redirecting to Myntra login...</div>;
}