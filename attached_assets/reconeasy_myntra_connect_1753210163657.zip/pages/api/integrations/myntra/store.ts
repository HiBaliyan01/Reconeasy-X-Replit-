import { drizzleDb } from "@/lib/db";
import { myntraCredentials } from "@/lib/schema";
import { encrypt } from "@/lib/crypto";

export async function POST(req: Request) {
  const { token } = await req.json();
  const encrypted = encrypt(token);
  const userId = "user-id-placeholder"; // Replace with actual user context

  await drizzleDb.insert(myntraCredentials).values({
    userId,
    token: encrypted,
  });

  return Response.json({ success: true });
}