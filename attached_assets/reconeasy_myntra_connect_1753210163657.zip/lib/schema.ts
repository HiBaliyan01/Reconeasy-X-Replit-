import { pgTable, text, uuid, timestamp } from "drizzle-orm/pg-core";

export const myntraCredentials = pgTable("myntra_credentials", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: text("user_id").notNull(),
  token: text("token").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});