import React, { useState } from 'react';
import Papa from 'papaparse';
import axios from 'axios';

export default function OrdersUpload() {
  const [orders, setOrders] = useState([]);
  const [fileName, setFileName] = useState('');
  const [uploadDate, setUploadDate] = useState(null);
  const [error, setError] = useState('');
  const [marketplace, setMarketplace] = useState('Amazon');

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        if (!results?.data?.length) {
          setError("CSV appears to be empty or malformed.");
          return;
        }
        setOrders(results.data);
        setUploadDate(new Date().toLocaleString());
        setError('');
      },
      error: (err) => setError("Parsing failed: " + err.message)
    });
  };

  const handleSave = async () => {
    try {
      await axios.post('/api/orders/upload', { orders, marketplace });
      alert("✅ Orders uploaded successfully!");
    } catch (err) {
      console.error(err);
      alert("❌ Upload failed. Check console for errors.");
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-teal-600 to-emerald-600 dark:from-teal-700 dark:to-emerald-700 rounded-xl p-6 text-white">
        <h2 className="text-2xl font-bold">Upload Orders CSV</h2>
        <p className="text-teal-100 mt-1">Upload your order data to enable reconciliation.</p>
        <div className="mt-4 space-x-4">
          <select value={marketplace} onChange={e => setMarketplace(e.target.value)} className="rounded px-3 py-2 text-black">
            <option>Amazon</option>
            <option>Flipkart</option>
            <option>Myntra</option>
            <option>Nykaa</option>
          </select>
          <a href="/templates/orders_template.csv" className="bg-white text-teal-600 px-4 py-2 rounded shadow hover:bg-teal-100">Download Template</a>
          <input type="file" accept=".csv" onChange={handleFileUpload} className="text-white" />
        </div>
        {fileName && <p className="mt-2 text-sm text-teal-200">📁 File: {fileName} | Uploaded at: {uploadDate}</p>}
        {error && <p className="text-red-300 mt-2">{error}</p>}
      </div>

      {orders.length > 0 && (
        <div className="overflow-auto rounded-lg shadow-lg border">
          <table className="min-w-full text-sm text-left text-gray-700">
            <thead className="bg-gray-100">
              <tr>
                {Object.keys(orders[0]).map((col, idx) => (
                  <th key={idx} className="px-4 py-2 border">{col}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {orders.slice(0, 10).map((row, idx) => (
                <tr key={idx} className="bg-white even:bg-gray-50">
                  {Object.values(row).map((cell, cid) => (
                    <td key={cid} className="px-4 py-2 border">{cell}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
          <div className="text-sm text-gray-500 px-4 py-2">Showing first 10 rows</div>
          <button onClick={handleSave} className="mt-4 ml-4 bg-teal-600 text-white px-4 py-2 rounded hover:bg-teal-700">Save Orders</button>
        </div>
      )}
    </div>
  );
}