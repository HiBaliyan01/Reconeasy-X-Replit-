import { NextApiRequest, NextApiResponse } from 'next';
import { drizzleDb } from '@/lib/db';
import { orders } from '@/lib/schema';
import { v4 as uuidv4 } from 'uuid';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end();
  const { orders: incomingOrders, marketplace } = req.body;

  try {
    const formatted = incomingOrders.map((row: any) => ({
      id: uuidv4(),
      brandId: "demo-brand",
      orderId: row.order_id,
      sku: row.sku,
      quantity: parseInt(row.quantity),
      sellingPrice: parseFloat(row.selling_price || 0),
      dispatchDate: row.dispatch_date ? new Date(row.dispatch_date) : null,
      orderStatus: row.order_status || 'Dispatched'
    }));

    await drizzleDb.insert(orders).values(formatted);
    res.status(200).json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to insert orders' });
  }
}