import { pgTable, uuid, text, integer, numeric, timestamp, date } from "drizzle-orm/pg-core";

export const orders = pgTable("orders", {
  id: uuid("id").defaultRandom().primaryKey(),
  brandId: text("brand_id").notNull(),
  orderId: text("order_id").notNull(),
  sku: text("sku").notNull(),
  quantity: integer("quantity").notNull(),
  sellingPrice: numeric("selling_price"),
  dispatchDate: date("dispatch_date"),
  orderStatus: text("order_status"),
  createdAt: timestamp("created_at").defaultNow(),
});