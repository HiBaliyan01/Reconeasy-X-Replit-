This Replit-ready ZIP includes:
- Claims Tracker table UI with filters, tooltips, and smart reminders
- Reconciliation summary stubbed in detail view (next phase)
- Working Bulk Actions: Update Status, Send Reminder
- Excel + PDF export
- Keyboard navigation & compact row select styling
- Color theme aligned with ReconEasy branding (#019875 & #FF6C5F)