// Settlements page placeholder
export default function Settlements() { return <div>Settlements Page</div>; }