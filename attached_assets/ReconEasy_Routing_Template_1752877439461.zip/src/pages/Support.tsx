
export default function Support() {
  return <div className="text-xl text-gray-700">🚧 Support Page – Coming soon...</div>;
}
