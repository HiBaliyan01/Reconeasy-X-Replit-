
export default function Analytics() {
  return <div className="text-xl text-gray-700">🚧 Analytics Page – Coming soon...</div>;
}
