
export default function Returns() {
  return <div className="text-xl text-gray-700">🚧 Returns Page – Coming soon...</div>;
}
