
export default function Payments() {
  return <div className="text-xl text-gray-700">🚧 Payments Page – Coming soon...</div>;
}
