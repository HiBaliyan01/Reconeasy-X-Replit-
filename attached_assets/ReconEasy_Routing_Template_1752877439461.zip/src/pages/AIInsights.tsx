
export default function AIInsights() {
  return <div className="text-xl text-gray-700">🚧 AIInsights Page – Coming soon...</div>;
}
