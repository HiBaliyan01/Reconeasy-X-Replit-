
export default function RateCards() {
  return <div className="text-xl text-gray-700">🚧 RateCards Page – Coming soon...</div>;
}
