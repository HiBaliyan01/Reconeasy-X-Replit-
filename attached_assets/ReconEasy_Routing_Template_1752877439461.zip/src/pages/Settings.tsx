
export default function Settings() {
  return <div className="text-xl text-gray-700">🚧 Settings Page – Coming soon...</div>;
}
