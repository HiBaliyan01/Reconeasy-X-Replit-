
export default function Transactions() {
  return <div className="text-xl text-gray-700">🚧 Transactions Page – Coming soon...</div>;
}
