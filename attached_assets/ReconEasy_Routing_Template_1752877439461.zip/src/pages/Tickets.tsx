
export default function Tickets() {
  return <div className="text-xl text-gray-700">🚧 Tickets Page – Coming soon...</div>;
}
