
export default function Dashboard() {
  return <div className="text-xl text-gray-700">🚧 Dashboard Page – Coming soon...</div>;
}
