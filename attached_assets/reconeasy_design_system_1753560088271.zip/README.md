# ReconEasy Design System Starter Kit

This package includes your core theme setup and reusable components:

## Included

### 🎨 CSS Theme Variables
- Primary (Action): #3B82F6
- Secondary (Background): #F9EDEB
- Negative/Positive: Red-Green scale
- Tertiary (Neutral): #6B7280
- Purple (AI/Assistant): #7C3AED
- Dark Mode Support: #1A202C / #E2E8F0

### 🏷️ Badge Component
Reusable React component to show status chips:
- Neutral (e.g., "Pending")
- Purple (e.g., "AI Suggestion")

## Setup
1. Import `theme.css` into your layout (or Tailwind layer).
2. Use `<Badge label="Awaiting UTR" />` or `<Badge label="AI Suggestion" variant="purple" />`.

## Notes
- Heatmap gradient uses teal range: #E0F2F1 → #00796B
- Extend with `user_theme` support via CSS variables switching in the future